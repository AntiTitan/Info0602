#include <json-c/json.h>
#include "struct.h"

#define MAX_SIZE 2048

int parsing(char* nomFichier, case_t** grille, robot_t robot, int, int);